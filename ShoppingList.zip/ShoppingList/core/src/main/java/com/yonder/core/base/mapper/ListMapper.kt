package com.yonder.core.base.mapper

/**
 * @author: yusufonder
 * @date: 05/06/2021
 */
interface ListMapper<I, O>: Mapper<List<I>, List<O>>

