package com.yonder.addtolist.domain.uimodel

/**
 * @author yusuf.onder
 * Created on 30.08.2021
 */
data class ProductEntityUiModel(
  val name: String,
  val categoryImage: String
)
