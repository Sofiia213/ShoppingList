package com.yonder.addtolist.core.extensions

/**
 * Yusuf Onder on 12,May,2021
 */

fun Int?.orZero() = this ?: 0
