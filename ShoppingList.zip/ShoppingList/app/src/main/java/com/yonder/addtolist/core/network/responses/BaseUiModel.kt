package com.yonder.addtolist.core.network.responses

/**
 * Yusuf Onder on 09,May,2021
 */

open class BaseUiModel(open val result: BaseUiResult)
