package com.yonder.addtolist.common.utils.formatter.currency

/**
 * @author yusuf.onder
 * Created on 22.08.2021
 */

object CurrencyProvider {
  const val DEFAULT_CURRENCY_SIGN = "$"
}
