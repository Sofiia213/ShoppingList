package com.yonder.addtolist.theme

import androidx.compose.ui.unit.dp


/**
 * @author yusuf.onder
 * Created on 22.11.2021
 */

val padding_4 = 4.dp
val padding_8 = 8.dp
val padding_16 = 16.dp
val padding_32 = 32.dp

