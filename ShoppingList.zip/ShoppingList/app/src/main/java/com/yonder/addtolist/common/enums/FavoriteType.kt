package com.yonder.addtolist.common.enums

/**
 * @author yusuf.onder
 * Created on 29.08.2021
 */
enum class FavoriteType(val value: Int) {
  Favorite(1);
}
