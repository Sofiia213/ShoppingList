package com.yonder.addtolist.core.network.request

/**
 * @author yusuf.onder
 * Created on 19.07.2021
 */
data class CreateUserListRequest(val name: String, val color: String, val uuid: String)
