package com.yonder.addtolist.domain.uimodel

/**
 * @author yusuf.onder
 * Created on 4.09.2021
 */
data class LanguageUiModel(
  val id : Int,
  val tag : String,
  val name : String,
  val image : String
)
