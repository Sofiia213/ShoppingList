package com.yonder.addtolist.core.network.exceptions

/**
 * @author yusuf.onder
 * Created on 20.07.2021
 */
private const val ROOM_ERROR_MESSAGE = "Room error occurred"
class RoomResultException : Throwable(ROOM_ERROR_MESSAGE)
