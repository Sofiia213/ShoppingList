package com.yonder.addtolist.theme

import androidx.compose.ui.unit.dp

/**
 * @author yusuf.onder
 * Created on 17.11.2021
 */

val profile_image_size = 128.dp
val profile_image_size_small = 48.dp

val default_page_padding = 16.dp

