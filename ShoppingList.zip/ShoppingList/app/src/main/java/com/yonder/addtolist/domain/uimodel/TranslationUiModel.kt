package com.yonder.addtolist.domain.uimodel

/**
 * Yusuf Onder on 12,May,2021
 */

data class TranslationUiModel(
  var name: String,
  var languageId: Int,
  var categoryId: Int
)
