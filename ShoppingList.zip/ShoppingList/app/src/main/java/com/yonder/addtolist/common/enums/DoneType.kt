package com.yonder.addtolist.common.enums

/**
 * @author yusuf.onder
 * Created on 29.08.2021
 */

enum class DoneType(val value: Int) {
  Done(1);
}

