package com.yonder.addtolist.domain.uimodel

/**
 * @author: yusufonder
 * @date: 05/06/2021
 */
data class UserListDataModel (val name : String)
